from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_endpoint_returns_ok():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_hello_endpoint_uses_name():
    response = client.get("/hello/Abhi")
    assert response.status_code == 200
    assert response.json()["message"] == "Hello, Abhi!"
